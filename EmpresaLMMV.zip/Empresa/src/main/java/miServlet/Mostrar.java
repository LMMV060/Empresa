package miServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Mostrar
 */
@WebServlet("/Mostrar")
public class Mostrar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Mostrar() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		try{
    		Class.forName("com.mysql.jdbc.Driver");
    		Connection conBD = DriverManager.getConnection(
    	            "jdbc:mysql://localhost:3306/evaluacion",
    	            "root", "123456");
    		
    		 if (!conBD.isClosed())
    		   {
    		      // La consulta
    		      Statement st = conBD.createStatement();
    		      ResultSet rs = st.executeQuery("select * from empleados" );

    		      // Ponemos los resultados en un table de html
    		      out.println("<table border=\"1\"><tr><td>Nombre</td><td>Sexo</td><td>DNI</td><td>Categoria</td></td><td>A�os</td></tr>");
    		      while (rs.next())
    		      {
    		    	  out.println("<tr>");
    		    	  out.println("<td>"+rs.getObject("nombre")+"</td>");
    		    	  out.println("<td>"+rs.getObject("sexo")+"</td>");
    		    	  out.println("<td>"+rs.getObject("dni")+"</td>");
    		    	  out.println("<td>"+rs.getObject("categoria")+"</td>");
    		    	  out.println("<td>"+rs.getObject("anyos")+"</td>");
    		    	  out.println("</tr>");
    		      }
    		      out.println("</table>");
    		      
    		      out.println("<p><a href=\"index.jsp\">Volver</a></p>");

    		      // cierre de la conexion
    		      conBD.close();
    		   }else{
    			// Error en la conexion
    			   out.println("fallo");
    		   }
    		      
    		
    	} catch (Exception error) {
    	    System.out.println("Error al conectar con el servidor MySQL/MariaDB: " + error.getMessage());
    	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
