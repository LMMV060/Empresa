package miServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BuscaSalario
 */
@WebServlet("/BuscaSalario")
public class BuscaSalario extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BuscaSalario() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			PrintWriter out = response.getWriter();
			String DNI = request.getParameter("DNI");
    		Class.forName("com.mysql.jdbc.Driver");
    		Connection conBD = DriverManager.getConnection(
    	            "jdbc:mysql://localhost:3306/evaluacion",
    	            "root", "123456");
    		
    		 if (!conBD.isClosed())
    		   {
    		      // La consulta
    		      Statement st = conBD.createStatement();
    		      ResultSet rs = st.executeQuery("select * from nomina where dni like '" + DNI + "';" );
    		      rs.next();
    		      if(DNI.equals(rs.getObject("dni"))) {
    		  		out.println("<html><body>");
    		  		out.println("<h1> El DNI " + DNI + " tiene un salario de "+rs.getObject("SUELDO_BASE")+"</h1>");
    		  		out.println("<a href=\"busqueda.jsp\">Volver</a>");
    		  		out.println("</body></html>");
    		      } else {
    		    	  RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
       			   	  rd.forward(request, response);
    		      }
    		      // cierre de la conexion
    		      conBD.close();
    		   }else{
    			   RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
    			   rd.forward(request, response);
    		   }
    		      
    		
    	} catch (Exception error) {
    		RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
			rd.forward(request, response);
    	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
