package miServlet;

import com.mysql.jdbc.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class Conectar {
    Connection co;  
    Statement stm;
    static Connection conBD = null;
    private static final String DB_NAME = "evaluacion";

    public static Connection iniciarConnection(){   
    	try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException error) {
            System.out.println("Error al cargar el driver JDBC de MySQL: " + error.getMessage());
        }
        
        try {
        	
            conBD = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/" + DB_NAME,
                    "root", "123456");
            
            System.out.println("Conectado con el servidor MySQL/MariaDB: " + DB_NAME);
        } catch (SQLException error) {
            System.out.println("Error al conectar con el servidor MySQL/MariaDB: " + error.getMessage());
        }
            return null;
    }
    
    public static void todo() {
    	iniciarConnection();
    	
    	Statement mStm = null;
        try {
            mStm = conBD.createStatement();
        } catch (SQLException error) {
            System.out.println("Error al establecer declaraci�n de conexi�n MySQL/MariaDB: " + error.getMessage());
        }
        
        ResultSet mRS = null;
        try {
            mRS = mStm.executeQuery("Select * from empleados");
            
            while (mRS.next()) {
                
            	
            } 
    } catch (SQLException error) {
        System.out.println("Error al ejecutar SQL en servidor MySQL/MariaDB: " + error.getMessage());
        
    
    
}
    }
}